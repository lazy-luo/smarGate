#!/bin/bash
# Usage: ./enable_autostart.sh on|off 

ACTION="$1"   # on / offa
APP_PWD=$(pwd) # Application path
APP_ARGS="-i1000 -o1000 -w4 -b" # Arguments
APP_PATH="$APP_PWD/proxy_server"

TASK_NAME="SGServer"
SERVICE_NAME="$TASK_NAME.service"
SERVICE_PATH="/etc/systemd/system/$SERVICE_NAME"
PLIST_NAME="com.$TASK_NAME.autostart.plist"
PLIST_PATH="$HOME/Library/LaunchAgents/$PLIST_NAME"
DESKTOP_DIR="$HOME/.config/autostart"
DESKTOP_FILE="$DESKTOP_DIR/$TASK_NAME.desktop"

OS="$(uname -s)"

exist_shell="ps -ef | grep \"$APP_PATH $APP_ARGS\" | grep -v grep >/dev/null"

enable_linux_server() {
    if [ "$ACTION" == "on" ]; then
        echo "[Linux] Setting up systemd service..."
        if systemctl is-enabled --quiet "$SERVICE_NAME" 2>/dev/null; then
            echo "[Linux] Already enabled, skipping"
        else
	    if ps -ef >/dev/null 2>&1;then
		exist_shell="if ! $exist_shell"
	    else
		exist_shell="found=0; for pid in /proc/[0-9]*; do cmd=\$(tr \"\\0\" \" \" < \"\$pid/cmdline\" 2>/dev/null); echo \"\$cmd\" | grep \"$APP_PATH $APP_ARGS\" | grep -v grep | grep -v \"\$0\" && found=1 && break; done; if [ \$found -eq 0 ]"
	    fi
            sudo bash -c "cat > $SERVICE_PATH" <<EOF
[Unit]
Description=$TASK_NAME Auto Start
After=network.target

[Service]
Type=forking
ExecStart=/bin/bash -c '$exist_shell; then cd $APP_PWD;$APP_PATH $APP_ARGS; else echo "Process already running"; fi'
Restart=on-failure
RestartSec=3
User=$USER

[Install]
WantedBy=multi-user.target
EOF
            sudo systemctl daemon-reload
            sudo systemctl enable "$SERVICE_NAME"
            sudo systemctl start "$SERVICE_NAME"
        fi
    else
        echo "[Linux] Disabling systemd auto-start..."
        sudo systemctl stop "$SERVICE_NAME" 2>/dev/null
        sudo systemctl disable "$SERVICE_NAME" 2>/dev/null
        sudo rm -f "$SERVICE_PATH"
        sudo systemctl daemon-reload
    fi
}

enable_linux_desktop() {
    mkdir -p "$DESKTOP_DIR"
    if [ "$ACTION" == "on" ]; then
        echo "[Linux] Setting up desktop environment auto-start..."
        if [ -f "$DESKTOP_FILE" ]; then
            echo "[Linux] Already exists, skipping"
        else
	    if ps -ef >/dev/null 2>&1;then
                exist_shell="if ! $exist_shell"
            else
                exist_shell="found=0; for pid in /proc/[0-9]*; do cmd=\$(tr \"\\0\" \" \" < \"\$pid/cmdline\" 2>/dev/null); echo \"\$cmd\" | grep \"$APP_PATH $APP_ARGS\" | grep -v grep | grep -v \"\$0\" && found=1 && break; done; if [ \$found -eq 0 ]"
            fi
	    cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Exec=/bin/bash -c '$exist_shell; then cd $APP_PWD;$APP_PATH $APP_ARGS; else echo "Process already running"; fi'
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Name=$TASK_NAME Auto Start
Comment=Start $TASK_NAME on login
EOF
        fi
    else
        echo "[Linux] Disabling desktop environment auto-start..."
        rm -f "$DESKTOP_FILE"
    fi
}

enable_linux() {
    # Check if it's a desktop environment (check DISPLAY or XDG_SESSION_TYPE)
    if [ -n "$DISPLAY" ] || [ "$XDG_SESSION_TYPE" = "x11" ] || [ "$XDG_SESSION_TYPE" = "wayland" ]; then
        enable_linux_desktop
    else
        enable_linux_server
    fi
}

enable_macos() {
    if [ "$ACTION" == "on" ]; then
        echo "[macOS] Setting up launchd..."
        if [ -f "$PLIST_PATH" ]; then
            echo "[macOS] Already exists, skipping"
        else
	    mac_ck=${exist_shell//\"/&quot;}
            mkdir -p "$(dirname "$PLIST_PATH")"
            cat > "$PLIST_PATH" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.$TASK_NAME.autostart</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>-c</string>
    <string>if ! $mac_ck; then cd $APP_PWD;$APP_PATH $APP_ARGS; else echo 'Process already running'; fi</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
</dict>
</plist>
EOF
            launchctl load -w "$PLIST_PATH"
        fi
    else
        echo "[macOS] Disabling launchd auto-start..."
        launchctl unload -w "$PLIST_PATH" 2>/dev/null
        rm -f "$PLIST_PATH"
    fi
}

case "$OS" in
    Darwin)
        enable_macos
        ;;
    Linux)
        enable_linux
        ;;
    *)
        echo "Unsupported operating system: $OS"
        exit 1
        ;;
esac

