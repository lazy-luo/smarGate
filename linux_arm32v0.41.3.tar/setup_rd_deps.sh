#!/bin/sh
# =============================================================================
# setup_rd_deps.sh  --  smartGate C++ server / remote-desktop runtime deps
#
# Prepares the FFmpeg (libavutil / libavcodec / libswscale) and OpenSSL
# (libssl / libcrypto) runtime libraries the server dlopen()s for the
# remote-desktop feature, and writes their absolute paths into conf-proxy.xml
# so the server can find them (the built-in name table stops at FFmpeg 7.x and
# does NOT contain the shipped FFmpeg 8.x names, so a bare install is enough to
# make remote desktop silently unavailable).
#
# Success criterion is NOT "the package is installed" but "the loaded
# libavcodec actually contains the libx264 encoder": the server withholds the
# remote-desktop capability bit (0x10) when libx264 is missing.
#
# Platforms : macOS (Homebrew) and Linux (apt / dnf / yum / zypper / pacman).
#             Windows uses the companion setup_rd_deps.ps1.
#
# Usage:
#   ./setup_rd_deps.sh                        # detect, install if missing, write conf
#   ./setup_rd_deps.sh --conf /path/conf-proxy.xml
#   ./setup_rd_deps.sh --no-install           # detect + write only, never touch the system
#   ./setup_rd_deps.sh --set-libs "libavcodec=/x/libavcodec.so;libssl=/x/libssl.so"  # skip detection (test hook)
#   ./setup_rd_deps.sh --help
#
# Exit codes:
#   0  all libraries resolved, verified (libx264 present) and conf written
#   1  fatal: a library is missing / install failed / conf could not be written
#   2  conf written, but libx264 could not be positively verified
# =============================================================================

LC_ALL=C
export LC_ALL
set -u

SELF_DIR=$(cd "$(dirname "$0")" && pwd 2>/dev/null) || SELF_DIR=$(dirname "$0")
CONF="$SELF_DIR/conf-proxy.xml"
DO_INSTALL=1
SET_LIBS=""
SET_LIBS_SEP=","

die()  { echo "ERROR: $*" >&2; exit 1; }
warn() { echo "WARN:  $*" >&2; }
info() { echo "[setup_rd_deps] $*"; }

usage() {
	cat <<EOF
setup_rd_deps.sh -- prepare FFmpeg + OpenSSL runtime libs and configure conf-proxy.xml

Usage:
  $0 [--conf PATH] [--no-install] [--set-libs "k=v;..."] [--help]

Options:
  --conf PATH      conf-proxy.xml to edit   (default: <script dir>/conf-proxy.xml)
  --no-install     only detect + configure; never install anything
  --set-libs LIST  skip detection and write these paths verbatim
                   (semicolon or comma separated: libavutil=v;libavcodec=v;
                    libswscale=v;libssl=v;libcrypto=v) -- mainly a test hook
  -h, --help       show this help

Exit: 0 ok | 1 fatal | 2 conf written but libx264 not verified
EOF
}

# ------------------------------------------------------------------ args ----
while [ $# -gt 0 ]; do
	case "$1" in
		--conf)       [ $# -ge 2 ] || die "--conf requires an argument"; CONF="$2"; shift 2 ;;
		--conf=*)     CONF="${1#--conf=}"; shift ;;
		--no-install) DO_INSTALL=0; shift ;;
		--set-libs)   [ $# -ge 2 ] || die "--set-libs requires an argument"; SET_LIBS="$2"; shift 2 ;;
		--set-libs=*) SET_LIBS="${1#--set-libs=}"; shift ;;
		-h|--help)    usage; exit 0 ;;
		*)            die "unknown argument: $1 (try --help)" ;;
	esac
done

# ------------------------------------------------------------- platform -----
OS=$(uname -s 2>/dev/null || echo unknown)
case "$OS" in
	Darwin) PLAT=mac ;;
	Linux)  PLAT=linux ;;
	*)      die "unsupported OS '$OS'; on Windows use setup_rd_deps.ps1" ;;
esac
info "platform: $PLAT  ($OS)"

# =================================================== graphical desktop =====
# Remote desktop needs a display: the Linux capture backend is X11
# (XOpenDisplay / XShmGetImage in remote_desktop_capture_linux.cpp), so on a
# headless host it cannot work and ffmpeg is not needed. Detection uses
# persistent/runtime signals rather than only $DISPLAY (empty in an SSH session
# on a GUI machine); ANY positive signal => "has a desktop".
has_graphical_desktop() {
	[ -n "${DISPLAY:-}" ] && return 0
	[ -n "${WAYLAND_DISPLAY:-}" ] && return 0
	for s in /tmp/.X11-unix/X*; do [ -S "$s" ] && return 0; done
	if command -v systemctl >/dev/null 2>&1; then
		systemctl is-active --quiet graphical.target 2>/dev/null && return 0
		systemctl is-active --quiet display-manager.service 2>/dev/null && return 0
		[ "$(systemctl get-default 2>/dev/null)" = graphical.target ] && return 0
	fi
	if command -v pgrep >/dev/null 2>&1; then
		for p in Xorg X Xwayland gnome-shell plasmashell weston sway; do
			pgrep -x "$p" >/dev/null 2>&1 && return 0
		done
	fi
	return 1
}

if [ "$PLAT" = linux ]; then
	if has_graphical_desktop; then
		HAVE_GUI=1
		info "graphical desktop detected (remote desktop can be served)"
	else
		HAVE_GUI=0
		warn "no graphical desktop detected (no X11/Wayland session)"
		warn "  the server's Linux screen capture is X11-based, so remote desktop"
		warn "  cannot work on this host: ffmpeg will NOT be installed or required."
		warn "  OpenSSL (display-independent) is still configured."
	fi
else
	HAVE_GUI=1
fi


# ============================================================ conf writer ===
# Writes the 5 keys into the <app-parameter> block of $CONF.
# Only ASCII bytes are inserted; every other byte (incl. GBK Chinese) is copied
# verbatim because awk runs under LC_ALL=C. Idempotent: existing lib* keys are
# replaced, never duplicated.
write_conf() {
	[ -f "$CONF" ] || die "conf file not found: $CONF"
	[ -w "$CONF" ] || die "conf file not writable: $CONF"

	bak="$CONF.bak.$(date +%Y%m%d%H%M%S 2>/dev/null || echo manual)"
	cp "$CONF" "$bak" || die "cannot back up $CONF -> $bak"
	info "backup: $bak"

	tmp="$CONF.tmp.$$"
	if grep -q '<app-parameter' "$CONF"; then
		awk -v v1="$LIB_AVUTIL" -v v2="$LIB_AVCODEC" -v v3="$LIB_SWSCALE" \
		    -v v4="$LIB_SSL" -v v5="$LIB_CRYPTO" '
			inblk && /<\/app-parameter>/ { inblk = 0; print; next }
			inblk && /^[[:space:]]*<lib(avutil|avcodec|swscale|ssl|crypto)[[:space:]>]/ { next }
			/<app-parameter/ && !inblk {
				print
				print "\t\t<libavutil value=\""  v1 "\"/>"
				print "\t\t<libavcodec value=\"" v2 "\"/>"
				print "\t\t<libswscale value=\"" v3 "\"/>"
				print "\t\t<libssl value=\""     v4 "\"/>"
				print "\t\t<libcrypto value=\""  v5 "\"/>"
				inblk = 1; next
			}
			{ print }
		' "$CONF" > "$tmp" || { rm -f "$tmp"; die "awk failed while editing $CONF"; }
	else
		awk -v v1="$LIB_AVUTIL" -v v2="$LIB_AVCODEC" -v v3="$LIB_SWSCALE" \
		    -v v4="$LIB_SSL" -v v5="$LIB_CRYPTO" '
			!done && /<app-config/ {
				print
				print "\t<app-parameter>"
				print "\t\t<libavutil value=\""  v1 "\"/>"
				print "\t\t<libavcodec value=\"" v2 "\"/>"
				print "\t\t<libswscale value=\"" v3 "\"/>"
				print "\t\t<libssl value=\""     v4 "\"/>"
				print "\t\t<libcrypto value=\""  v5 "\"/>"
				print "\t</app-parameter>"
				done = 1; next
			}
			{ print }
		' "$CONF" > "$tmp" || { rm -f "$tmp"; die "awk failed while editing $CONF"; }
	fi

	cp "$tmp" "$CONF" || { rm -f "$tmp"; die "cannot write $CONF"; }
	rm -f "$tmp"

	# read-back assertion: exactly one of each key must now be present
	for k in libavutil libavcodec libswscale libssl libcrypto; do
		n=$(grep -c "<$k " "$CONF")
		[ "$n" -eq 1 ] || die "read-back failed: expected exactly 1 <$k> in $CONF, found $n"
	done
	info "wrote 5 lib keys into $CONF"
}

# Read an existing key's value from inside <app-parameter> (empty if absent).
conf_get() {
	[ -f "$CONF" ] || return 0
	awk -v k="$1" '
		/<app-parameter/    { inblk = 1 }
		/<\/app-parameter>/ { inblk = 0 }
		inblk && index($0, "<" k) {
			if (match($0, /value="[^"]*"/)) {
				print substr($0, RSTART + 7, RLENGTH - 8)
				exit
			}
		}
	' "$CONF"
}

# On a headless host we do not resolve/require ffmpeg. If discovery found none,
# keep whatever ffmpeg path the conf already holds instead of blanking it --
# this guards against a headless-looking run (e.g. via SSH) wiping a valid config.
preserve_ffmpeg_existing() {
	[ "$HAVE_GUI" = 0 ] || return 0
	for pair in "libavutil:LIB_AVUTIL" "libavcodec:LIB_AVCODEC" "libswscale:LIB_SWSCALE"; do
		k=${pair%%:*}; var=${pair#*:}
		eval "cur=\$$var"
		[ -n "$cur" ] && continue
		old=$(conf_get "$k")
		if [ -n "$old" ]; then
			eval "$var=\"\$old\""
			info "headless: keeping existing $k from conf: $old"
		fi
	done
}

# ============================================================ --set-libs ====
if [ -n "$SET_LIBS" ]; then
	LIB_AVUTIL=""; LIB_AVCODEC=""; LIB_SWSCALE=""; LIB_SSL=""; LIB_CRYPTO=""
	_oldifs=$IFS
	IFS=';'
	for kv in $SET_LIBS; do
		IFS=$_oldifs
		# also accept comma separation
		IFS=';'
		[ -n "$kv" ] || continue
		# allow comma inside the list too
		case "$kv" in
			*,*) for kv2 in $(printf '%s' "$kv" | tr ',' ';' | tr ';' ' '); do
					k=${kv2%%=*}; v=${kv2#*=}
					case "$k" in
						libavutil) LIB_AVUTIL=$v;; libavcodec) LIB_AVCODEC=$v;;
						libswscale) LIB_SWSCALE=$v;; libssl) LIB_SSL=$v;; libcrypto) LIB_CRYPTO=$v;;
						*) IFS=$_oldifs; die "unknown lib key: $k";;
					esac
				done ;;
			*)  k=${kv%%=*}; v=${kv#*=}
				case "$k" in
					libavutil) LIB_AVUTIL=$v;; libavcodec) LIB_AVCODEC=$v;;
					libswscale) LIB_SWSCALE=$v;; libssl) LIB_SSL=$v;; libcrypto) LIB_CRYPTO=$v;;
					*) IFS=$_oldifs; die "unknown lib key: $k";;
				esac ;;
		esac
		IFS=';'
	done
	IFS=$_oldifs
	for pair in "libavutil:$LIB_AVUTIL" "libavcodec:$LIB_AVCODEC" "libswscale:$LIB_SWSCALE" \
	            "libssl:$LIB_SSL" "libcrypto:$LIB_CRYPTO"; do
		[ -n "${pair#*:}" ] || die "--set-libs: missing value for ${pair%%:*}"
	done
	write_conf
	exit 0
fi

# ======================================================== discovery (mac) ===
pick_mac_lib() { # $1 dir, $2 base -> prints path, rc=0 if found
	d=$1; b=$2
	[ -e "$d/$b.dylib" ] && { printf '%s\n' "$d/$b.dylib"; return 0; }
	for f in "$d/$b".[0-9]*.dylib; do
		[ -e "$f" ] && { printf '%s\n' "$f"; return 0; }
	done
	return 1
}

mac_pick() { # $1 base, rest = candidate dirs
	b=$1; shift
	for d in "$@"; do
		[ -d "$d" ] || continue
		p=$(pick_mac_lib "$d" "$b") && { printf '%s\n' "$p"; return 0; }
	done
	return 1
}

# ====================================================== discovery (linux) ===
linux_pick() { # $1 base -> highest-versioned soname path via ldconfig, else scan
	b=$1
	if command -v ldconfig >/dev/null 2>&1; then
		p=$(ldconfig -p 2>/dev/null | awk -v b="$b" '
			index($0, b ".so") {
				n = split($1, a, "."); v = a[n] + 0
				if (v >= 0 && v >= best) { best = v; path = $NF }
			}
			END { if (path != "") print path }')
		[ -n "$p" ] && { printf '%s\n' "$p"; return 0; }
	fi
	for d in /usr/lib /usr/lib64 /lib /lib64 /usr/local/lib \
	         /usr/lib/x86_64-linux-gnu /usr/lib/aarch64-linux-gnu /lib/x86_64-linux-gnu; do
		[ -d "$d" ] || continue
		for f in "$d/$b".so*; do
			[ -e "$f" ] && { printf '%s\n' "$f"; return 0; }
		done
	done
	return 1
}

# ================================================================ install ===
do_install() {
	if [ "$DO_INSTALL" != 1 ]; then
		warn "missing libraries and --no-install was given; skipping installation"
		return 1
	fi
	if [ "$PLAT" = mac ]; then
		command -v brew >/dev/null 2>&1 || \
			die "Homebrew not found; install it from https://brew.sh then re-run (or pass --set-libs)"
		info "installing ffmpeg + openssl@3 via Homebrew ..."
		brew install ffmpeg openssl@3 || brew install ffmpeg openssl || return 1
		return 0
	fi

	SUDO=""
	[ "$(id -u)" = 0 ] || { command -v sudo >/dev/null 2>&1 && SUDO="sudo"; }
	# ffmpeg (+ its x264 encoder) is only needed where remote desktop can run;
	# on a headless host we install OpenSSL only.
	if command -v apt-get >/dev/null 2>&1; then
		info "installing via apt-get ..."
		$SUDO apt-get update
		if [ "$HAVE_GUI" = 1 ]; then
			$SUDO apt-get install -y ffmpeg libssl3 || $SUDO apt-get install -y ffmpeg
		else
			info "headless host: installing OpenSSL only (no ffmpeg)"
			$SUDO apt-get install -y libssl3 || true
		fi
	elif command -v dnf >/dev/null 2>&1; then
		if [ "$HAVE_GUI" = 1 ]; then
			info "installing via dnf ..."
			$SUDO dnf install -y ffmpeg x264-libs
		else
			info "headless host: skipping ffmpeg/x264 install"
		fi
	elif command -v yum >/dev/null 2>&1; then
		if [ "$HAVE_GUI" = 1 ]; then
			info "installing via yum ..."
			$SUDO yum install -y ffmpeg x264-libs
		else
			info "headless host: skipping ffmpeg/x264 install"
		fi
	elif command -v zypper >/dev/null 2>&1; then
		if [ "$HAVE_GUI" = 1 ]; then
			info "installing via zypper ..."
			$SUDO zypper install -y ffmpeg
		else
			info "headless host: skipping ffmpeg install"
		fi
	elif command -v pacman >/dev/null 2>&1; then
		if [ "$HAVE_GUI" = 1 ]; then
			info "installing via pacman ..."
			$SUDO pacman -S --noconfirm ffmpeg x264
		else
			info "headless host: skipping ffmpeg/x264 install"
		fi
	else
		die "no supported package manager found; install ffmpeg (incl. libx264) and openssl manually"
	fi
	rc=$?
	[ "$rc" = 0 ] || warn "package installation returned non-zero ($rc); will re-check discovery"
	return 0
}

# =============================================================== discovery ==
run_discovery() {
	LIB_AVUTIL=""; LIB_AVCODEC=""; LIB_SWSCALE=""; LIB_SSL=""; LIB_CRYPTO=""
	if [ "$PLAT" = mac ]; then
		BREW_PREFIX=""
		command -v brew >/dev/null 2>&1 && BREW_PREFIX=$(brew --prefix 2>/dev/null)
		FF_DIRS="$BREW_PREFIX/opt/ffmpeg/lib $BREW_PREFIX/lib /usr/local/lib /opt/homebrew/lib"
		SSL_DIRS="$BREW_PREFIX/opt/openssl@3/lib $BREW_PREFIX/opt/openssl@1.1/lib \
		          $BREW_PREFIX/opt/openssl/lib $BREW_PREFIX/lib \
		          /usr/local/opt/openssl@3/lib /opt/homebrew/opt/openssl@3/lib"
		# shellcheck disable=SC2086
		LIB_AVUTIL=$(mac_pick libavutil  $FF_DIRS)
		# shellcheck disable=SC2086
		LIB_AVCODEC=$(mac_pick libavcodec $FF_DIRS)
		# shellcheck disable=SC2086
		LIB_SWSCALE=$(mac_pick libswscale $FF_DIRS)
		# shellcheck disable=SC2086
		LIB_SSL=$(mac_pick libssl    $SSL_DIRS)
		# shellcheck disable=SC2086
		LIB_CRYPTO=$(mac_pick libcrypto $SSL_DIRS)
	else
		LIB_AVUTIL=$(linux_pick libavutil)
		LIB_AVCODEC=$(linux_pick libavcodec)
		LIB_SWSCALE=$(linux_pick libswscale)
		LIB_SSL=$(linux_pick libssl)
		LIB_CRYPTO=$(linux_pick libcrypto)
	fi
}

# Missing REQUIRED libraries. The ffmpeg keys only count when a desktop exists
# (HAVE_GUI=1): on a headless host ffmpeg is neither installed nor required.
missing_list() {
	for p in "libavutil:$LIB_AVUTIL" "libavcodec:$LIB_AVCODEC" "libswscale:$LIB_SWSCALE" \
	         "libssl:$LIB_SSL" "libcrypto:$LIB_CRYPTO"; do
		[ -n "${p#*:}" ] && continue
		case "${p%%:*}" in
			libavutil|libavcodec|libswscale) [ "$HAVE_GUI" = 1 ] || continue ;;
		esac
		printf '%s ' "${p%%:*}"
	done
}

# ================================================================== staging ==
# Copy the discovered libs into <conf dir>/shared/lib and point the 5 keys there,
# matching the Windows script so every platform keeps the runtime libs in one
# place next to conf-proxy.xml (self-contained deployment, short stable paths).
# Only the 5 resolved files are copied (-L dereferences symlinks so each staged
# file is real content); on mac/linux the sibling dependencies resolve through
# the libraries' own install_names / the system loader, so no siblings needed.
# Skipped entirely on the --set-libs path (that exits before run_discovery).
stage_libs() {
	_conf_dir=$(cd "$(dirname "$CONF")" 2>/dev/null && pwd) || _conf_dir=$(dirname "$CONF")
	[ -n "$_conf_dir" ] || _conf_dir=.
	SHARED_LIB="$_conf_dir/shared/lib"

	_staged=0
	for _var in LIB_AVUTIL LIB_AVCODEC LIB_SWSCALE LIB_SSL LIB_CRYPTO; do
		eval "_p=\$$_var"
		[ -n "$_p" ] || continue
		[ -e "$_p" ] || { warn "stage_libs: $_var source missing, leaving as-is: $_p"; continue; }
		_leaf=$(basename "$_p")
		_src_dir=$(cd "$(dirname "$_p")" 2>/dev/null && pwd) || _src_dir=$(dirname "$_p")
		if [ "$_src_dir" = "$SHARED_LIB" ]; then
			eval "$_var=\"\$SHARED_LIB/\$_leaf\""
			continue
		fi
		mkdir -p "$SHARED_LIB" || { warn "stage_libs: cannot create $SHARED_LIB"; return 0; }
		if cp -fL "$_p" "$SHARED_LIB/$_leaf" 2>/dev/null; then
			eval "$_var=\"\$SHARED_LIB/\$_leaf\""
			_staged=$((_staged + 1))
		else
			warn "stage_libs: failed to copy $_p -> $SHARED_LIB/$_leaf (keeping original)"
		fi
	done
	[ "$_staged" -gt 0 ] && info "staged $_staged lib(s) into $SHARED_LIB"
	return 0
}

run_discovery
miss=$(missing_list)
if [ -n "$miss" ]; then
	info "missing: $miss"
	do_install || true
	run_discovery
	miss=$(missing_list)
	[ -z "$miss" ] || die "still missing after install: $miss"
fi

stage_libs
preserve_ffmpeg_existing

info "libavutil  = $LIB_AVUTIL"
info "libavcodec = $LIB_AVCODEC"
info "libswscale = $LIB_SWSCALE"
info "libssl     = $LIB_SSL"
info "libcrypto  = $LIB_CRYPTO"

# ============================================================ libx264 check =
# rc: 0 = libx264 positively present; 1 = a checker ran but found no libx264;
#     2 = no checker available (cannot verify either way)
verify_x264() {
	ran=0
	if command -v ffmpeg >/dev/null 2>&1; then
		ran=1
		ffmpeg -hide_banner -encoders 2>/dev/null | grep -qw libx264 && return 0
	fi
	# the nm/strings checks need a resolved libavcodec path; skip them if none
	if [ -n "$LIB_AVCODEC" ] && command -v nm >/dev/null 2>&1; then
		ran=1
		case "$PLAT" in
			mac)   nm -gU "$LIB_AVCODEC" 2>/dev/null | grep -q '_ff_libx264_encoder' && return 0 ;;
			linux) nm -D  "$LIB_AVCODEC" 2>/dev/null | grep -q 'ff_libx264_encoder'  && return 0 ;;
		esac
	fi
	if [ -n "$LIB_AVCODEC" ] && command -v strings >/dev/null 2>&1; then
		ran=1
		strings "$LIB_AVCODEC" 2>/dev/null | grep -q 'libx264' && return 0
	fi
	[ "$ran" = 1 ] && return 1
	return 2
}

write_conf

# Headless host: no ffmpeg was resolved (nothing to verify) and remote desktop
# cannot run here regardless -- this is not a failure, so exit 0, not 2.
if [ "$HAVE_GUI" = 0 ] && [ -z "$LIB_AVCODEC" ]; then
	warn "headless host: ffmpeg not configured; remote desktop is unavailable here anyway."
	info "conf written (OpenSSL only); done."
	exit 0
fi

verify_x264
vrc=$?
if [ "$vrc" = 0 ]; then
	info "libx264 verified in the loaded libavcodec"
	info "done."
	exit 0
elif [ "$vrc" = 2 ]; then
	warn "conf written, but libx264 could not be verified (no ffmpeg CLI / nm / strings)."
	warn "The server needs libx264 to advertise remote desktop; check with: ffmpeg -encoders | grep libx264"
	exit 2
else
	warn "libx264 NOT found in $LIB_AVCODEC."
	warn "Remote desktop will stay unavailable until a libx264-enabled FFmpeg is installed."
	exit 2
fi
