param(
    [string]$on   # "on" or "off"
)

if (-not $on ) {
    Write-Output "Usage: .\enable_autostart.ps1 on|off"
    exit 1
}
$scriptPath = $MyInvocation.MyCommand.Definition
$app = Split-Path -Parent $scriptPath
$app += "\\proxy_server.exe -i1000 -o1000 -w4 -b"

# Check for administrator privileges
$IsAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent() `
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $IsAdmin) {
    Write-Output "No administrator privileges. Trying to run as administrator..."
    try {
        Start-Process powershell -ArgumentList "-ExecutionPolicy Bypass -File `"$scriptPath`" $on" -Verb RunAs
    } catch {
	Write-Output "Failt to run as administrator!"
    }
    exit
}

$taskName = "SGServer"

if ($on -eq "on") {
    if (schtasks /Query /TN $taskName 2>$null) {
        Write-Output "Auto-start task already exists, skipping."
        exit 0
    }
    Write-Output "Setting up auto-start at login..."
    schtasks /Create /TN $taskName /TR "`"$app`"" /SC ONSTART /RL HIGHEST /F /RU SYSTEM
}
elseif ($on -eq "off") {
    Write-Output "Removing auto-start task..."
    schtasks /Delete /TN $taskName /F 2>$null
}
else {
    Write-Output ("Parameter error: {0}. Use 'on' or 'off'." -f $on)
    exit 1
}
