# =============================================================================
# setup_rd_deps.ps1  --  smartGate C++ server / remote-desktop runtime deps (Windows)
#
# Companion to setup_rd_deps.sh. Prepares the FFmpeg (avutil / avcodec / swscale)
# and OpenSSL (libssl / libcrypto) runtime DLLs the server LoadLibrary()s for the
# remote-desktop feature, and writes their absolute paths into conf-proxy.xml so
# the server can find them (the built-in name table stops at FFmpeg 7.x and does
# NOT contain the shipped FFmpeg 8.x names avcodec-63/avutil-61/swscale-10, so a
# bare install is enough to make remote desktop silently unavailable).
#
# Success criterion is NOT "the package is installed" but "the loaded avcodec
# actually contains the libx264 encoder": the server withholds the remote-desktop
# capability bit (0x10) when libx264 is missing.
#
# On Windows the same conf keys are also read by the server itself AND passed to
# the sg_rd_agent.exe it launches (--avutil / --avcodec / --swscale).
#
# ARCHITECTURE: the shipped Windows server is 32-bit (Win32/x86) or ARM64 -- NOT
# x64 (see LazyServer/LazyServer.vcxproj). An x64 ffmpeg DLL cannot be loaded
# into a 32-bit process (LoadLibrary -> ERROR_BAD_EXE_FORMAT / 193), so the
# ffmpeg build is chosen by the SERVER's architecture (-Arch / -ServerExe),
# never by the OS arch. The staged DLLs are PE-header checked before conf is
# written, so a wrong-arch package fails loudly instead of at server runtime.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File setup_rd_deps.ps1
#   powershell ... -File setup_rd_deps.ps1 -Conf C:\path\conf-proxy.xml
#   powershell ... -File setup_rd_deps.ps1 -NoInstall      # detect + write only
#   powershell ... -File setup_rd_deps.ps1 -SetLibs "avutil=C:\ffmpeg\bin\avutil-61.dll;..."   # test hook
#
# Exit codes:
#   0  all libraries resolved, verified (libx264 present) and conf written
#   1  fatal: a library is missing / install failed / conf could not be written
#   2  conf written, but libx264 could not be positively verified
# =============================================================================

[CmdletBinding()]
param(
    [string]$Conf = "",
    [string]$Arch = "",
    [string]$ServerExe = "",
    [switch]$NoInstall,
    [string]$SetLibs = "",
    [string]$FfmpegZip = "",
    [string]$FfmpegUrl = "",
    [string]$Mirror = "",
    [string]$Proxy = "",
    [string]$Sha256 = "",
    [switch]$Help
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Die  { param([string]$msg) Write-Host "ERROR: $msg" -ForegroundColor Red;     exit 1 }
function Warn { param([string]$msg) Write-Host "WARN:  $msg" -ForegroundColor Yellow }
function Info { param([string]$msg) Write-Host "[setup_rd_deps] $msg" }

if ($Help) {
    @"
setup_rd_deps.ps1 -- prepare FFmpeg + OpenSSL runtime DLLs and configure conf-proxy.xml

Usage:
  setup_rd_deps.ps1 [-Conf PATH] [-Arch x86|x64|arm64] [-ServerExe PATH]
                    [-NoInstall] [-SetLibs "k=v;..."] [-Help]

Options:
  -Conf PATH      conf-proxy.xml to edit   (default: <script dir>\conf-proxy.xml).
                  The DLLs are staged into <Conf dir>\shared\lib.
  -Arch ARCH      architecture of the SERVER (x86|x64|arm64). Defaults to the
                  arch read from -ServerExe's PE header, else a proxy_server.exe /
                  sg_rd_agent.exe next to the conf, else x86 (the shipped Win32
                  server). The ffmpeg build is chosen to match THIS, not the OS.
  -ServerExe PATH read the target architecture from this executable's PE header
  -NoInstall      only detect + configure; never install anything
  -SetLibs LIST   skip detection and write these paths verbatim
                  (semicolon or comma separated: avutil=v;avcodec=v;swscale=v;
                   libssl=v;libcrypto=v) -- mainly a test hook

  Download fallback (used when winget/choco cannot fetch the DLLs, e.g. GitHub
  is blocked; the shared ffmpeg zip is the ONLY DLL source winget offers, and
  winget/choco only offer it for x64):
  -FfmpegZip PATH   use this local ffmpeg *-full_build-shared.zip (no network)
  -FfmpegUrl URL    download this archive URL instead of the arch default
  -Mirror PREFIX    prepend PREFIX to the default GitHub URL, e.g.
                    https://ghproxy.net/   (tried before the built-in mirrors)
  -Proxy URL        proxy for the download, e.g. http://127.0.0.1:7890
                    (also honours $env:HTTPS_PROXY / $env:HTTP_PROXY)
  -Sha256 HEX       expected SHA-256 of the archive (defaults to the known hash
                    of the x64 Gyan 9.0.2 shared zip when that is the source)

  Whatever source the DLLs are found in (winget's deep Packages tree, choco, a
  downloaded zip, ...), ONLY the needed runtime DLLs (avutil/avcodec/swscale/
  swresample + libssl/libcrypto) are COPIED into <Conf dir>\shared\lib -- never
  the exes or the unrelated avformat/avfilter/avdevice DLLs -- and conf-proxy.xml
  is written with those local ABSOLUTE paths. The short stable path keeps the
  conf readable and co-locates libavcodec with its sibling avutil/swresample: the
  server opens an absolute lib path with
  LoadLibraryEx(LOAD_WITH_ALTERED_SEARCH_PATH), which searches the DLL's own
  folder for its dependencies -- no PATH edit needed. Every staged DLL is
  PE-header checked against -Arch, so a wrong-arch package fails loudly instead
  of at server runtime (LoadLibrary -> 193).
  -Help           show this help

Exit: 0 ok | 1 fatal | 2 conf written but libx264 not verified
"@ | Write-Host
    exit 0
}

if ([string]::IsNullOrEmpty($Conf)) {
    $Conf = Join-Path $PSScriptRoot "conf-proxy.xml"
}

# ------------------------------------------------------------------- paths ----
# Files are read/written as Latin1 (code page 28591): each byte <-> one char, so
# a multiline round-trip is byte-exact and non-ASCII bytes (e.g. GBK Chinese in
# the conf) survive untouched. Only ASCII is ever inserted.
$Latin1 = [System.Text.Encoding]::GetEncoding(28591)

# ---------------------------------------------------------------- layout ------
# ffmpeg + openssl DLLs are staged next to the conf, under shared\lib, so conf
# holds a short stable path and the sibling DLLs live in one folder the server
# can resolve them from (LOAD_WITH_ALTERED_SEARCH_PATH).
$ConfDir = Split-Path -Parent $Conf
if ([string]::IsNullOrEmpty($ConfDir)) { $ConfDir = (Get-Location).Path }
$SharedLibDir = Join-Path $ConfDir "shared\lib"

# ----------------------------------------------------------- architecture -----
# The SERVER's bitness decides which ffmpeg build is correct. x64 runtime DLLs
# cannot be loaded by the 32-bit server (LoadLibrary -> ERROR_BAD_EXE_FORMAT /
# 193); that mismatch is exactly what this replaces.
function Get-PeMachine {
    param([string]$Path)
    if ([string]::IsNullOrEmpty($Path) -or -not (Test-Path -LiteralPath $Path)) { return 0 }
    $fs = $null
    try {
        $fs = [System.IO.File]::OpenRead($Path)
        $br = [System.IO.BinaryReader]::new($fs)
        if ($br.ReadUInt16() -ne 0x5A4D) { return 0 }                    # 'MZ'
        $fs.Seek(0x3C, [System.IO.SeekOrigin]::Begin) | Out-Null
        $peOff = $br.ReadUInt32()
        $fs.Seek($peOff, [System.IO.SeekOrigin]::Begin) | Out-Null
        if ($br.ReadUInt32() -ne 0x00004550) { return 0 }                # 'PE\0\0'
        return $br.ReadUInt16()                                          # COFF Machine
    } catch { return 0 } finally { if ($fs) { $fs.Dispose() } }
}

function Resolve-TargetArch {
    if (-not [string]::IsNullOrEmpty($Arch)) {
        switch ($Arch.ToLower()) {
            "x86"   { return "x86" }
            "x64"   { return "x64" }
            "arm64" { return "arm64" }
            default { Die "-Arch must be x86, x64 or arm64 (got '$Arch')" }
        }
    }
    $exe = $ServerExe
    if ([string]::IsNullOrEmpty($exe)) {
        foreach ($n in @("proxy_server.exe", "sg_rd_agent.exe")) {
            $c = Join-Path $ConfDir $n
            if (Test-Path -LiteralPath $c) { $exe = $c; break }
        }
    }
    switch (Get-PeMachine $exe) {
        0x014C  { return "x86" }
        0x8664  { return "x64" }
        0xAA64  { return "arm64" }
        default {
            Warn "cannot determine the server architecture (no -Arch/-ServerExe and no readable PE header); assuming x86 (the shipped Win32 server). Pass -Arch x86|x64|arm64 to override."
            return "x86"
        }
    }
}

$TargetArch = Resolve-TargetArch
Info "target architecture: $TargetArch (ffmpeg build chosen to match the server)"

function Read-ConfText {
    param([string]$path)
    return $Latin1.GetString([System.IO.File]::ReadAllBytes($path))
}

function Write-ConfBytes {
    param([string]$path, [byte[]]$bytes)
    [System.IO.File]::WriteAllBytes($path, $bytes)
}

# ============================================================ conf writer ====
# Writes the 5 keys into the <app-parameter> block of $Conf. Idempotent: existing
# lib* keys inside the block are dropped and re-emitted, never duplicated.
function Write-Conf {
    if (-not (Test-Path -LiteralPath $Conf)) { Die "conf file not found: $Conf" }

    $stamp = Get-Date -Format "yyyyMMddHHmmss"
    $bak = "$Conf.bak.$stamp"
    Copy-Item -LiteralPath $Conf -Destination $bak -Force
    Info "backup: $bak"

    $text = Read-ConfText $Conf
    # Normalise to LF for line processing; remember the dominant EOL to restore.
    $crlf = $text.Contains("`r`n")
    $lines = ($text -replace "`r`n", "`n") -split "`n"

    $hasAppParam = $text -match '<app-parameter'
    $ins = @(
        "`t`t<libavutil value=""$LIB_AVUTIL""/>",
        "`t`t<libavcodec value=""$LIB_AVCODEC""/>",
        "`t`t<libswscale value=""$LIB_SWSCALE""/>",
        "`t`t<libssl value=""$LIB_SSL""/>",
        "`t`t<libcrypto value=""$LIB_CRYPTO""/>"
    )

    $out = New-Object System.Collections.Generic.List[string]
    $dropRe = '^[ \t]*<lib(avutil|avcodec|swscale|ssl|crypto)[ \t>]'

    if ($hasAppParam) {
        $inblk = $false
        foreach ($ln in $lines) {
            if ($inblk -and $ln -match '</app-parameter>') { $out.Add($ln); $inblk = $false; continue }
            if ($inblk -and ($ln -match $dropRe)) { continue }
            if ((-not $inblk) -and ($ln -match '<app-parameter')) {
                $out.Add($ln)
                foreach ($k in $ins) { $out.Add($k) }
                $inblk = $true
                continue
            }
            $out.Add($ln)
        }
    } else {
        $done = $false
        foreach ($ln in $lines) {
            if ((-not $done) -and ($ln -match '<app-config')) {
                $out.Add($ln)
                $out.Add("`t<app-parameter>")
                foreach ($k in $ins) { $out.Add($k) }
                $out.Add("`t</app-parameter>")
                $done = $true
                continue
            }
            $out.Add($ln)
        }
    }

    $newText = ($out -join "`n")
    if ($crlf) { $newText = $newText -replace "`n", "`r`n" }
    $bytes = $Latin1.GetBytes($newText)

    $tmp = "$Conf.tmp.$PID"
    Write-ConfBytes $tmp $bytes
    Copy-Item -LiteralPath $tmp -Destination $Conf -Force
    Remove-Item -LiteralPath $tmp -Force

    # read-back assertion: exactly one of each key must now be present
    $verify = Read-ConfText $Conf
    foreach ($k in @("libavutil", "libavcodec", "libswscale", "libssl", "libcrypto")) {
        $n = ([regex]::Matches($verify, "<$k ")).Count
        if ($n -ne 1) { Die "read-back failed: expected exactly 1 <$k> in $Conf, found $n" }
    }
    Info "wrote 5 lib keys into $Conf"
}

# ============================================================= -SetLibs =====
if (-not [string]::IsNullOrEmpty($SetLibs)) {
    $LIB_AVUTIL = ""; $LIB_AVCODEC = ""; $LIB_SWSCALE = ""; $LIB_SSL = ""; $LIB_CRYPTO = ""
    $parts = $SetLibs -split '[;,]'
    foreach ($kv in $parts) {
        if ([string]::IsNullOrEmpty($kv)) { continue }
        $eq = $kv.IndexOf('=')
        if ($eq -lt 0) { Die "bad -SetLibs entry (expected k=v): $kv" }
        $k = $kv.Substring(0, $eq); $v = $kv.Substring($eq + 1)
        switch ($k) {
            "libavutil"  { $LIB_AVUTIL  = $v }
            "libavcodec" { $LIB_AVCODEC = $v }
            "libswscale" { $LIB_SWSCALE = $v }
            "libssl"     { $LIB_SSL     = $v }
            "libcrypto"  { $LIB_CRYPTO  = $v }
            default      { Die "unknown lib key: $k" }
        }
    }
    foreach ($pair in @("libavutil:$LIB_AVUTIL", "libavcodec:$LIB_AVCODEC", "libswscale:$LIB_SWSCALE", "libssl:$LIB_SSL", "libcrypto:$LIB_CRYPTO")) {
        if ([string]::IsNullOrEmpty($pair.Substring($pair.IndexOf(':') + 1))) {
            Die "-SetLibs: missing value for $($pair.Substring(0, $pair.IndexOf(':')))"
        }
    }
    Write-Conf
    exit 0
}

# =============================================================== discovery ==
# Flat search dirs: script dir, server working dir, PATH entries, the ffmpeg.exe
# dir, and the common manual install locations. (winget keeps only shims in
# Links; the real DLLs are nested under Packages -> searched via Get-SearchRoots.)
function Get-SearchDirs {
    $dirs = New-Object System.Collections.Generic.List[string]
    $dirs.Add($PSScriptRoot)
    $dirs.Add((Get-Location).Path)
    $dirs.Add((Join-Path $PSScriptRoot "bin"))
    $dirs.Add($SharedLibDir)
    $dirs.Add((Join-Path $PSScriptRoot "ffmpeg\bin"))
    if ($env:PATH) {
        foreach ($p in ($env:PATH -split ';')) { if ($p -ne "") { $dirs.Add($p) } }
    }
    $ff = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if ($ff -and $ff.Source) { $dirs.Add((Split-Path -Parent $ff.Source)) }
    $dirs.Add("C:\ffmpeg\bin")
    $dirs.Add("C:\ffmpeg")
    if ($env:ProgramFiles)        { $dirs.Add((Join-Path $env:ProgramFiles "ffmpeg\bin")) }
    if (${env:ProgramFiles(x86)}) { $dirs.Add((Join-Path ${env:ProgramFiles(x86)} "ffmpeg\bin")) }
    if ($env:ProgramData)         { $dirs.Add((Join-Path $env:ProgramData "chocolatey\bin")) }
    if ($env:LOCALAPPDATA)        { $dirs.Add((Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links")) }
    if ($env:ProgramFiles)        { $dirs.Add((Join-Path $env:ProgramFiles "WinGet\Links")) }
    foreach ($drv in @("C:", "D:")) {
        $dirs.Add("$drv\OpenSSL-Win64\bin")
        $dirs.Add("$drv\Program Files\OpenSSL-Win64\bin")
    }
    # de-dup, keep order
    return ($dirs | Where-Object { $_ -ne "" } | Select-Object -Unique)
}

# Directories searched RECURSIVELY: the package trees where DLLs sit several
# levels down (e.g. WinGet\Packages\Gyan.FFmpeg.Shared_*\ffmpeg-<v>-full_build-shared\bin).
function Get-SearchRoots {
    $r = New-Object System.Collections.Generic.List[string]
    if ($env:LOCALAPPDATA) { $r.Add((Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages")) }
    if ($env:ProgramFiles) { $r.Add((Join-Path $env:ProgramFiles "WinGet\Packages")) }
    if ($env:ProgramData)  { $r.Add((Join-Path $env:ProgramData "chocolatey\lib")) }
    $r.Add("C:\ffmpeg")
    return ($r | Where-Object { $_ -ne "" } | Select-Object -Unique)
}

# A freshly installed package updates the machine/user PATH in the registry, but
# this already-running shell keeps its old copy -- re-read it.
function Refresh-Path {
    $m = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $u = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:PATH = (@($m, $u, $env:PATH) | Where-Object { $_ }) -join ";"
}

function ConvertTo-GlobRegex {
    param([string]$g)
    return '^' + ([regex]::Escape($g) -replace '\\\*', '.*' -replace '\\\?', '.') + '$'
}

# Highest-versioned DLL matching any pattern, searching $Dirs flat and $Roots
# recursively. Returns the full path, or $null.
function Find-Dll {
    param([string[]]$Patterns, [string[]]$Dirs = @(), [string[]]$Roots = @())
    $alts = @($Patterns | ForEach-Object { ConvertTo-GlobRegex $_ })
    $rx = [regex]::new('(' + ($alts -join '|') + ')',
                       [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    $best = $null; $bestVer = -1
    $sets = New-Object System.Collections.Generic.List[object]
    foreach ($d in $Dirs) {
        if (-not (Test-Path -LiteralPath $d)) { continue }
        $sets.Add(@(Get-ChildItem -LiteralPath $d -File -ErrorAction SilentlyContinue))
    }
    foreach ($r in $Roots) {
        if (-not (Test-Path -LiteralPath $r)) { continue }
        $sets.Add(@(Get-ChildItem -LiteralPath $r -File -Recurse -Depth 6 -ErrorAction SilentlyContinue))
    }
    foreach ($set in $sets) {
        foreach ($h in $set) {
            if (-not $rx.IsMatch($h.Name)) { continue }
            $v = 0
            $m = [regex]::Match($h.Name, '(\d+)')
            if ($m.Success) { $v = [int]$m.Groups[1].Value }
            if ($v -gt $bestVer) { $bestVer = $v; $best = $h.FullName }
        }
    }
    return $best
}

function Invoke-Discovery {
    $dirs  = @(Get-SearchDirs)
    $roots = @(Get-SearchRoots)
    $Script:LIB_AVUTIL  = Find-Dll @("avutil*.dll")   $dirs $roots
    $Script:LIB_AVCODEC = Find-Dll @("avcodec*.dll")  $dirs $roots
    $Script:LIB_SWSCALE = Find-Dll @("swscale*.dll")  $dirs $roots
    $Script:LIB_SSL     = Find-Dll @("libssl*.dll", "ssleay32.dll")   $dirs $roots
    $Script:LIB_CRYPTO  = Find-Dll @("libcrypto*.dll", "libeay32.dll") $dirs $roots
}

function Get-MissingList {
    $miss = New-Object System.Collections.Generic.List[string]
    foreach ($pair in @("libavutil:$LIB_AVUTIL", "libavcodec:$LIB_AVCODEC", "libswscale:$LIB_SWSCALE", "libssl:$LIB_SSL", "libcrypto:$LIB_CRYPTO")) {
        if ([string]::IsNullOrEmpty($pair.Substring($pair.IndexOf(':') + 1))) {
            $miss.Add($pair.Substring(0, $pair.IndexOf(':')))
        }
    }
    return $miss
}

# ================================================= download fallback =========
# winget/choco fetch the shared-ffmpeg zip from github.com, which is often
# unreachable from mainland China (and the zip is the ONLY source of the DLLs).
# This fallback downloads the matching-ARCHIVE for the SERVER's architecture
# through an optional proxy / mirror, or unpacks a locally-obtained copy.
#
# The archive is keyed by ARCHITECTURE, never by the OS arch: the shipped
# Windows server is Win32/x86 or ARM64 and rejects x64 DLLs with 193. Only Gyan
# publishes an x64 build; x86/arm64 come from System233's msvc prebuilts (also
# a plain GitHub release zip, so the same mirror/proxy fallback covers it).
$FFMPEG_ARCH = @{
    "x64"   = @{
        Url    = "https://github.com/GyanD/codexffmpeg/releases/download/9.0.2/ffmpeg-9.0.2-full_build-shared.zip"
        Sha256 = "8D31E162F1616E37AAB3FA2DB991B97E1B8DBEB1C8465FD81A81BE16FF91B328"
    }
    "x86"   = @{
        Url    = "https://github.com/System233/ffmpeg-msvc-prebuilt/releases/download/ffmpeg-8.1.3/ffmpeg-8.1.3_x86-windows-shared-gpl.zip"
        Sha256 = ""
    }
    "arm64" = @{
        Url    = "https://github.com/System233/ffmpeg-msvc-prebuilt/releases/download/ffmpeg-8.1.3/ffmpeg-8.1.3_arm64-windows-shared-gpl.zip"
        Sha256 = ""
    }
}
$OFFICIAL_ZIP  = $FFMPEG_ARCH[$TargetArch].Url
$KNOWN_SHA256  = $FFMPEG_ARCH[$TargetArch].Sha256
$OFFICIAL_NAME = Split-Path -Leaf $OFFICIAL_ZIP

# Which PE Machine value a given target arch expects (0 = unknown/unreadable).
function Test-ArchMatch {
    param([int]$Machine, [string]$Arch)
    switch ($Arch) {
        "x86"   { return ($Machine -eq 0x014C) }
        "x64"   { return ($Machine -eq 0x8664) }
        "arm64" { return ($Machine -eq 0xAA64) }
    }
    return $false
}

function Get-ProxyUrl {
    if (-not [string]::IsNullOrEmpty($Proxy)) { return $Proxy }
    foreach ($v in @($env:HTTPS_PROXY, $env:HTTP_PROXY, $env:ALL_PROXY)) {
        if (-not [string]::IsNullOrEmpty($v)) { return $v }
    }
    return ""
}

# Download $Url to $Dest. Prefers curl.exe (bundled since Win10 1803; has native
# proxy + redirect handling), falls back to Invoke-WebRequest. Returns $true/$false.
# Bounded on purpose: a dead-but-accepting mirror must NOT hang the script, so we
# cap the connect time, the total time, and stall (abort if <1 KB/s for 2 min).
function Save-Url {
    param([string]$Url, [string]$Dest)
    $px = Get-ProxyUrl
    if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
        $curlArgs = @("-L", "--fail", "--progress-bar", "--show-error",
                      "--connect-timeout", "20", "--max-time", "1800",
                      "--speed-limit", "1024", "--speed-time", "120",
                      "-o", $Dest)
        if (-not [string]::IsNullOrEmpty($px)) { $curlArgs += @("-x", $px) }
        $curlArgs += $Url
        & curl.exe @curlArgs
        if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $Dest)) { return $true }
        return $false
    }
    try {
        $req = @{ Uri = $Url; OutFile = $Dest; UseBasicParsing = $true; TimeoutSec = 1800 }
        if (-not [string]::IsNullOrEmpty($px)) { $req.Proxy = $px }
        Invoke-WebRequest @req
        return (Test-Path -LiteralPath $Dest)
    } catch {
        Warn "download error: $($_.Exception.Message)"
        return $false
    }
}

# Verify the archive hash. Only enforces when we know the expected value: the
# user's -Sha256, or the built-in hash when the file is the arch default zip
# (only the x64 Gyan build has a pinned hash; System233 assets are unpinned).
function Test-ZipHash {
    param([string]$Path, [string]$Url = "")
    $want = $Sha256
    if ([string]::IsNullOrEmpty($want) -and -not [string]::IsNullOrEmpty($KNOWN_SHA256) -and ($Url -like "*$OFFICIAL_NAME")) {
        $want = $KNOWN_SHA256
    }
    if ([string]::IsNullOrEmpty($want)) { return $true }
    $got = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    if ($got -ieq $want) { return $true }
    Warn "sha256 mismatch: got $got want $want"
    return $false
}

# Candidate archive URLs, tried in order. github.com is frequently unreachable
# from mainland China, so the plain GitHub URL is tried LAST and several domestic
# GitHub mirrors (ghproxy-style "<mirror>/<full github url>" prefixes) come first.
function Get-FfmpegUrls {
    $list = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrEmpty($FfmpegUrl)) { $list.Add($FfmpegUrl) }
    if (-not [string]::IsNullOrEmpty($Mirror))    { $list.Add($Mirror.TrimEnd('/') + "/" + $OFFICIAL_ZIP) }
    foreach ($m in @(
        "https://ghproxy.net/",
        "https://ghfast.top/",
        "https://gh-proxy.com/"
    )) {
        $list.Add($m + $OFFICIAL_ZIP)
    }
    $list.Add($OFFICIAL_ZIP)
    return ($list | Select-Object -Unique)
}

# Only these runtime DLLs are ever staged. avformat/avfilter/avdevice/postproc
# (and the ffmpeg/ffplay/ffprobe exes) are deliberately NOT copied -- the
# remote-desktop encoder only LoadLibrary()s avutil + avcodec + swscale, and
# avcodec pulls in swresample. libssl/libcrypto are staged only if found (the
# Windows server statically links OpenSSL, so they are usually absent/inert).
$NEEDED_DLL_GLOBS = @(
    "avutil*.dll", "avcodec*.dll", "swscale*.dll", "swresample*.dll",
    "libssl*.dll", "libcrypto*.dll"
)

# Copy just the needed DLLs from $FromDir into $ToDir. Returns the count copied.
function Copy-NeededDlls {
    param([string]$FromDir, [string]$ToDir)
    if ([string]::IsNullOrEmpty($FromDir) -or -not (Test-Path -LiteralPath $FromDir)) { return 0 }
    New-Item -ItemType Directory -Force -Path $ToDir | Out-Null
    $n = 0
    foreach ($g in $NEEDED_DLL_GLOBS) {
        foreach ($f in @(Get-ChildItem -LiteralPath $FromDir -File -Filter $g -ErrorAction SilentlyContinue)) {
            $dst = Join-Path $ToDir $f.Name
            if ($f.FullName -eq $dst) { continue }
            try { Copy-Item -LiteralPath $f.FullName -Destination $dst -Force; $n++ }
            catch { Warn "copy failed: $($f.FullName) -> $dst ($($_.Exception.Message))" }
        }
    }
    return $n
}

# Unpack the shared-ffmpeg zip; copy ONLY the needed DLLs into $SharedLibDir.
function Expand-FfmpegZip {
    param([string]$Zip)
    $stage = Join-Path $env:TEMP ("ffmpeg-rd-stage-" + [Guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Force -Path $stage | Out-Null
    try { Expand-Archive -LiteralPath $Zip -DestinationPath $stage -Force }
    catch { Warn "unzip failed: $($_.Exception.Message)"; Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue; return $false }
    $av = Get-ChildItem -LiteralPath $stage -Recurse -File -Filter "avcodec-*.dll" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $av) {
        Warn "archive has no avcodec-*.dll (static build? need the *-full_build-shared zip)"
        Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
        return $false
    }
    $mach = Get-PeMachine $av.FullName
    if (-not (Test-ArchMatch $mach $TargetArch)) {
        Warn "archive's avcodec is not a $TargetArch binary (PE Machine 0x$('{0:X4}' -f $mach)) -- wrong package for the $TargetArch server"
        Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
        return $false
    }
    $n = Copy-NeededDlls -FromDir $av.Directory.FullName -ToDir $SharedLibDir
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
    Info "staged $n DLL(s) into $SharedLibDir"
    return $true
}

function Invoke-DownloadFfmpeg {
    if (-not [string]::IsNullOrEmpty($FfmpegZip)) {
        if (-not (Test-Path -LiteralPath $FfmpegZip)) { Warn "FfmpegZip not found: $FfmpegZip"; return $false }
        if (-not (Test-ZipHash -Path $FfmpegZip)) { return $false }
        Info "using local archive: $FfmpegZip"
        return (Expand-FfmpegZip -Zip $FfmpegZip)
    }
    foreach ($u in @(Get-FfmpegUrls)) {
        $tmp = Join-Path $env:TEMP ("ffmpeg-rd-" + [Guid]::NewGuid().ToString("N") + ".zip")
        Info "downloading $u ..."
        if (-not (Save-Url -Url $u -Dest $tmp)) { Warn "download failed: $u"; continue }
        if (-not (Test-ZipHash -Path $tmp -Url $u)) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue; continue }
        $ok = Expand-FfmpegZip -Zip $tmp
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
        if ($ok) { Info "staged ffmpeg DLLs into $SharedLibDir"; return $true }
    }
    Warn "all ffmpeg download sources failed (network / proxy?). Remedy: download the *-full_build-shared.zip manually and re-run with -FfmpegZip PATH"
    return $false
}

function Test-FfmpegMissing {
    param([string[]]$Missing)
    foreach ($k in @("libavutil", "libavcodec", "libswscale")) {
        if ($Missing -contains $k) { return $true }
    }
    return $false
}

# Stage the needed runtime DLLs into $SharedLibDir (next to the conf, under
# shared\lib) and point the 5 keys there when the local copy exists. Two reasons:
#   * conf-proxy.xml then holds a short, stable path instead of the deep
#     %LOCALAPPDATA%\...\WinGet\Packages\...\bin tree, which is hard to read and
#     moves when winget upgrades the package;
#   * libavcodec finds its siblings (avutil/swresample) in that one folder, so
#     the server's LOAD_WITH_ALTERED_SEARCH_PATH open works.
# Only the needed DLLs are copied (see $NEEDED_DLL_GLOBS) -- never the exes or
# the unrelated avformat/avfilter/avdevice DLLs.
function Stage-LibsLocal {
    $map = [ordered]@{
        "libavutil"  = $LIB_AVUTIL
        "libavcodec" = $LIB_AVCODEC
        "libswscale" = $LIB_SWSCALE
        "libssl"     = $LIB_SSL
        "libcrypto"  = $LIB_CRYPTO
    }
    # Distinct source folders that are not already the target folder.
    $srcDirs = New-Object System.Collections.Generic.List[string]
    foreach ($p in $map.Values) {
        if ([string]::IsNullOrEmpty($p)) { continue }
        $d = Split-Path -Parent $p
        if ($d -ne $SharedLibDir -and -not $srcDirs.Contains($d)) { $srcDirs.Add($d) }
    }
    $copied = 0
    foreach ($d in $srcDirs) { $copied += (Copy-NeededDlls -FromDir $d -ToDir $SharedLibDir) }
    # Re-point each key to the staged copy ONLY when that file really exists there
    # (a copy failure must not leave the conf pointing at a missing path).
    foreach ($k in @("libavutil", "libavcodec", "libswscale", "libssl", "libcrypto")) {
        if ([string]::IsNullOrEmpty($map[$k])) { continue }
        $local = Join-Path $SharedLibDir (Split-Path -Leaf $map[$k])
        if (Test-Path -LiteralPath $local) {
            Set-Variable -Name ("LIB_" + $k.Substring(3).ToUpper()) -Value $local -Scope Script
        }
    }
    if ($srcDirs.Count -gt 0) { Info "staged $copied DLL(s) from $($srcDirs.Count) folder(s) into $SharedLibDir" }
}

function Invoke-Install {
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    # choco/winget only ship an x64 ffmpeg; for an x86/arm64 server, ffmpeg must
    # come from the download fallback (System233 x86/arm64 shared zip), so we
    # still install OpenSSL via the package manager but NOT ffmpeg.
    $ffFromPkg = ($TargetArch -eq "x64")
    if (-not $ffFromPkg) {
        Info "target arch is ${TargetArch}: choco/winget only ship the x64 ffmpeg -- ffmpeg will come from the download fallback"
    }
    if (Get-Command choco -ErrorAction SilentlyContinue) {
        if ($ffFromPkg) {
            Info "installing ffmpeg + openssl via Chocolatey ..."
            if (-not $isAdmin) { Warn "Chocolatey usually needs an elevated shell; attempting anyway" }
            & choco install -y ffmpeg openssl
            if ($LASTEXITCODE -ne 0) { Warn "choco exited with code $LASTEXITCODE" }
        } else {
            Info "installing openssl via Chocolatey ..."
            if (-not $isAdmin) { Warn "Chocolatey usually needs an elevated shell; attempting anyway" }
            & choco install -y openssl
            if ($LASTEXITCODE -ne 0) { Warn "choco exited with code $LASTEXITCODE" }
        }
        Refresh-Path
        return $true
    }
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        if ($ffFromPkg) {
            # Gyan.FFmpeg is the STATIC build (exe only, NO DLLs) -- useless for
            # the server, which dlopen()s the DLLs. The SHARED variant ships them.
            Info "installing ffmpeg (shared build, ships the DLLs) via winget ..."
            & winget install --id Gyan.FFmpeg.Shared -e --accept-source-agreements --accept-package-agreements
            if ($LASTEXITCODE -ne 0) { Warn "winget ffmpeg exited with code $LASTEXITCODE (GitHub likely unreachable)" }
        }
        Info "installing openssl via winget (ShiningLight.OpenSSL) ..."
        & winget install --id ShiningLight.OpenSSL -e --accept-source-agreements --accept-package-agreements
        if ($LASTEXITCODE -ne 0) { Warn "winget openssl exited with code $LASTEXITCODE" }
        Refresh-Path
        return $true
    }
    Warn "no package manager (choco / winget) found"
    return $false
}

Refresh-Path
Invoke-Discovery
$missing = @(Get-MissingList)
if ($missing.Count -gt 0) {
    Info ("missing: " + ($missing -join " "))
    if ($NoInstall) {
        Warn "missing libraries and -NoInstall was given; skipping installation"
        Die ("still missing: " + ($missing -join " "))
    }
    if (-not (Invoke-Install)) {
        Warn "no package manager available; relying on the download fallback for ffmpeg"
    }
    Refresh-Path
    Invoke-Discovery
    $missing = @(Get-MissingList)
    if ($missing.Count -gt 0 -and (Test-FfmpegMissing $missing)) {
        Warn ("ffmpeg DLLs not found after install: " + (($missing | Where-Object { $_ -in "libavutil","libavcodec","libswscale" }) -join " "))
        Warn "trying the arch-matched download fallback (proxy/mirror/local zip) ..."
        if (Invoke-DownloadFfmpeg) {
            Refresh-Path
            Invoke-Discovery
            $missing = @(Get-MissingList)
        }
    }
    if ($missing.Count -gt 0) {
        Warn ("these DLLs are still not locatable after install: " + ($missing -join " "))
        Warn "download the shared build for the $TargetArch server and re-run with -FfmpegZip PATH, or place the DLLs in C:\ffmpeg\bin"
        Die ("still missing after install: " + ($missing -join " "))
    }
}

Stage-LibsLocal

Info "libavutil  = $LIB_AVUTIL"
Info "libavcodec = $LIB_AVCODEC"
Info "libswscale = $LIB_SWSCALE"
Info "libssl     = $LIB_SSL"
Info "libcrypto  = $LIB_CRYPTO"

# ==================================================== arch verification ======
# Every ffmpeg DLL we are about to point the conf at must match the SERVER's
# architecture; loading a wrong-arch DLL is exactly what produces a bare NULL
# from LoadLibrary with GetLastError == 193. Fail loudly here instead.
function Assert-LibArch {
    param([string]$Key, [string]$Path)
    if ([string]::IsNullOrEmpty($Path)) { return }
    if (-not (Test-Path -LiteralPath $Path)) {
        Die "$Key points at a file that does not exist: $Path"
    }
    $mach = Get-PeMachine $Path
    if ($mach -eq 0) {
        Warn "$Key is not a readable PE image (skipping arch check): $Path"
        return
    }
    if (-not (Test-ArchMatch $mach $TargetArch)) {
        Die "$Key is not a $TargetArch binary (PE Machine 0x$('{0:X4}' -f $mach)): $Path`n      the server is $TargetArch and will fail to load it (LoadLibrary -> 193). Re-run with an $TargetArch ffmpeg build."
    }
}

foreach ($k in @("libavcodec", "libavutil", "libswscale")) {
    $v = Get-Variable -Name ("LIB_" + $k.Substring(3).ToUpper()) -ValueOnly -Scope Script
    Assert-LibArch -Key $k -Path $v
}

# ============================================================ libx264 check =
# rc: 0 = positively present; 1 = checked but not found; 2 = no way to check
function Test-X264 {
    $ran = $false
    if (Get-Command ffmpeg -ErrorAction SilentlyContinue) {
        $ran = $true
        $enc = & ffmpeg -hide_banner -encoders 2>$null
        if ($enc -match 'libx264') { return 0 }
    }
    if (-not [string]::IsNullOrEmpty($LIB_AVCODEC) -and (Test-Path -LiteralPath $LIB_AVCODEC)) {
        $ran = $true
        $txt = $Latin1.GetString([System.IO.File]::ReadAllBytes($LIB_AVCODEC))
        if ($txt.Contains("libx264")) { return 0 }
    }
    if ($ran) { return 1 }
    return 2
}

Write-Conf
$vrc = Test-X264
if ($vrc -eq 0) {
    Info "libx264 verified in the loaded avcodec"
    Info "done."
    exit 0
} elseif ($vrc -eq 2) {
    Warn "conf written, but libx264 could not be verified (no ffmpeg CLI)."
    Warn "The server needs libx264 to advertise remote desktop; check with: ffmpeg -encoders | findstr libx264"
    exit 2
} else {
    Warn "libx264 NOT found in $LIB_AVCODEC."
    Warn "Remote desktop will stay unavailable until a libx264-enabled FFmpeg is installed."
    exit 2
}
